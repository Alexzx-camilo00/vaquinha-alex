# Planejamento - Site de Vaquinha Alex

## Estrutura de Páginas

### 1. Página Inicial (index.html)
- **Título**: "Ajude o Alex a bater a meta!"
- **Meta**: "Meta: R$400"
- **Barra de progresso**: Horizontal, azul brilhante, mostra valor atual/meta
- **Botão**: "AJUDAR" (laranja, leva para página 2)

### 2. Página de Seleção (selecao.html)
- **Pergunta**: "Quanto você gostaria de ajudar?"
- **Botões**: R$20, R$30, R$40, R$50, R$100, EU ESCOLHO
- **Navegação**: Cada botão leva para página específica

### 3-7. Páginas de Doação Pré-definidas
- **doacao-20.html**: R$20 + Chave Pix específica
- **doacao-30.html**: R$30 + Chave Pix específica  
- **doacao-40.html**: R$40 + Chave Pix específica
- **doacao-50.html**: R$50 + Chave Pix específica
- **doacao-100.html**: R$100 + Chave Pix específica

**Elementos comuns das páginas de doação**:
- Valor da doação escolhida
- Chave Pix (texto "Copia e Cola")
- Botão "Copiar"
- Botão "PRONTO" (vai para agradecimento)
- Botão "DESISTIR" (volta para inicial, cancela progresso)

### 8. Página EU ESCOLHO (eu-escolho.html)
- **Pergunta**: "Quanto você gostaria de doar?"
- **Campo**: Input numérico para valor
- **Botão**: "Continuar" (vai para página com Pix genérico)
- **Chave Pix genérica**: Fornecida pelo usuário

### 9. Página de Agradecimento (obrigado.html)
- **Texto**: "Obrigado, você é especial"
- **Botão**: Voltar para página inicial

## Chaves Pix por Valor

### R$20
```
00020126700014br.gov.bcb.pix0120alexmito28@gmail.com0224Obrigado! Voce e demais!520400005303986540520.005802BR5925ALEXSANDRO CAMILO DE SOUZ6009Sao Paulo62290525REC6886519269750875416835630483CB
```

### R$30
```
00020126650014br.gov.bcb.pix0120alexmito28@gmail.com0219Valeuuuuuuuuuuuuuui520400005303986540530.005802BR5925ALEXSANDRO CAMILO DE SOUZ6009Sao Paulo62290525REC688651FC4D14630714376763042251
```

### R$40
```
00020126700014br.gov.bcb.pix0120alexmito28@gmail.com0224Muito obrigado pelos 40!520400005303986540540.005802BR5925ALEXSANDRO CAMILO DE SOUZ6009Sao Paulo62290525REC6886523277E2F3059204116304CFCC
```

### R$50
```
00020126700014br.gov.bcb.pix0120alexmito28@gmail.com0224ta podendo em! Obrigado!520400005303986540550.005802BR5925ALEXSANDRO CAMILO DE SOUZ6009Sao Paulo62290525REC6886525FB884593662170663047D1C
```

### R$100
```
00020126730014br.gov.bcb.pix0120alexmito28@gmail.com0227Nuuuuuu, valeu de maissssss5204000053039865406100.005802BR5925ALEXSANDRO CAMILO DE SOUZ6009Sao Paulo62290525REC6886528C4165776642965463043DB5
```

### Genérica (EU ESCOLHO)
```
00020126990014br.gov.bcb.pix0136228431b0-f7f4-4ae6-a3ff-ffec4086ed120237Cofrinho de Alexsandro Camilo De Souz5204000053039865802BR5925Alexsandro Camilo De Souz6007IGARAPE61083290000062270523COFRMzg2MjgyNzAxMDAwMDM63046510
```

## Design Specifications

### Cores
- **Fundo**: Degradê preto para laranja escuro
- **Barra de progresso**: Azul brilhante
- **Botões principais**: Laranja
- **Texto**: Branco/claro para contraste

### Layout Mobile-First
- Botões grandes e fáceis de tocar
- Texto legível em telas pequenas
- Espaçamento adequado entre elementos
- Transições suaves entre páginas

### Funcionalidades JavaScript
- Navegação SPA (Single Page Application)
- Atualização dinâmica da barra de progresso
- Funcionalidade de copiar Pix
- Sistema de "DESISTIR" que reverte progresso
- Transições fade/slide entre páginas
- Validação de input numérico

## Fluxo de Dados
- **Progresso atual**: Armazenado em localStorage
- **Valor temporário**: Para controle de "DESISTIR"
- **Meta total**: R$400 (fixo)

