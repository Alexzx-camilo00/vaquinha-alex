// Variáveis globais
let currentProgress = 0;
let tempValue = 0;
let customValue = 0;
const META_TOTAL = 400;

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    loadProgress();
    updateProgressBar();
});

// Carregar progresso do localStorage
function loadProgress() {
    const saved = localStorage.getItem('vaquinha-progress');
    if (saved) {
        currentProgress = parseFloat(saved);
    }
}

// Salvar progresso no localStorage
function saveProgress() {
    localStorage.setItem('vaquinha-progress', currentProgress.toString());
}

// Atualizar barra de progresso
function updateProgressBar() {
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-text');
    
    const percentage = Math.min((currentProgress / META_TOTAL) * 100, 100);
    
    if (progressFill) {
        progressFill.style.width = percentage + '%';
    }
    
    if (progressText) {
        progressText.textContent = `R$${currentProgress.toFixed(0)} de R$${META_TOTAL}`;
    }
}

// Navegação entre páginas
function navigateTo(pageId) {
    // Esconder todas as páginas
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.classList.remove('active');
    });
    
    // Mostrar página específica
    const targetPage = document.getElementById('page-' + pageId);
    if (targetPage) {
        setTimeout(() => {
            targetPage.classList.add('active');
        }, 150);
    }
    
    // Atualizar barra de progresso se voltando para inicial
    if (pageId === 'inicial') {
        updateProgressBar();
    }
}

// Selecionar valor pré-definido
function selectValue(value) {
    tempValue = value;
    navigateTo('doacao-' + value);
}

// Processar valor customizado
function processCustomValue() {
    const input = document.getElementById('custom-value');
    const value = parseFloat(input.value);
    
    if (!value || value <= 0) {
        alert('Por favor, digite um valor válido maior que zero.');
        return;
    }
    
    customValue = value;
    tempValue = value;
    
    // Atualizar título da página de doação customizada
    const title = document.getElementById('custom-donation-title');
    if (title) {
        title.textContent = `Doação de R$${value.toFixed(2)}`;
    }
    
    navigateTo('doacao-custom');
}

// Copiar chave Pix
function copyPix(elementId) {
    const pixElement = document.getElementById(elementId);
    const copyBtn = pixElement.nextElementSibling;
    
    if (pixElement) {
        // Selecionar e copiar o texto
        pixElement.select();
        pixElement.setSelectionRange(0, 99999); // Para mobile
        
        try {
            document.execCommand('copy');
            
            // Feedback visual
            const originalText = copyBtn.textContent;
            copyBtn.textContent = 'Copiado!';
            copyBtn.classList.add('copied');
            
            setTimeout(() => {
                copyBtn.textContent = originalText;
                copyBtn.classList.remove('copied');
            }, 2000);
            
        } catch (err) {
            // Fallback para navegadores que não suportam execCommand
            if (navigator.clipboard) {
                navigator.clipboard.writeText(pixElement.value).then(() => {
                    const originalText = copyBtn.textContent;
                    copyBtn.textContent = 'Copiado!';
                    copyBtn.classList.add('copied');
                    
                    setTimeout(() => {
                        copyBtn.textContent = originalText;
                        copyBtn.classList.remove('copied');
                    }, 2000);
                });
            } else {
                alert('Não foi possível copiar automaticamente. Por favor, selecione e copie manualmente.');
            }
        }
    }
}

// Completar doação pré-definida
function completeDonation(value) {
    currentProgress += value;
    tempValue = 0;
    saveProgress();
    updateProgressBar();
    navigateTo('obrigado');
}

// Completar doação customizada
function completeCustomDonation() {
    currentProgress += customValue;
    tempValue = 0;
    customValue = 0;
    saveProgress();
    updateProgressBar();
    navigateTo('obrigado');
}

// Cancelar doação (desistir)
function cancelDonation() {
    tempValue = 0;
    customValue = 0;
    
    // Limpar campo customizado
    const customInput = document.getElementById('custom-value');
    if (customInput) {
        customInput.value = '';
    }
    
    navigateTo('inicial');
}

// Função para resetar progresso (para testes)
function resetProgress() {
    currentProgress = 0;
    tempValue = 0;
    customValue = 0;
    localStorage.removeItem('vaquinha-progress');
    updateProgressBar();
    navigateTo('inicial');
}

// Adicionar suporte a gestos de swipe (opcional)
let startX = 0;
let startY = 0;

document.addEventListener('touchstart', function(e) {
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
});

document.addEventListener('touchend', function(e) {
    if (!startX || !startY) {
        return;
    }
    
    const endX = e.changedTouches[0].clientX;
    const endY = e.changedTouches[0].clientY;
    
    const diffX = startX - endX;
    const diffY = startY - endY;
    
    // Verificar se é um swipe horizontal significativo
    if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
        // Swipe para a direita (voltar)
        if (diffX < 0) {
            const currentPage = document.querySelector('.page.active');
            if (currentPage && currentPage.id !== 'page-inicial') {
                // Lógica simples de voltar
                if (currentPage.id.includes('doacao')) {
                    cancelDonation();
                } else if (currentPage.id === 'page-selecao') {
                    navigateTo('inicial');
                } else if (currentPage.id === 'page-eu-escolho') {
                    navigateTo('selecao');
                } else if (currentPage.id === 'page-obrigado') {
                    navigateTo('inicial');
                }
            }
        }
    }
    
    startX = 0;
    startY = 0;
});

// Adicionar suporte ao botão voltar do navegador
window.addEventListener('popstate', function(e) {
    // Implementar lógica de navegação baseada no histórico se necessário
});

// Validação de entrada para campo numérico
document.addEventListener('DOMContentLoaded', function() {
    const customInput = document.getElementById('custom-value');
    if (customInput) {
        customInput.addEventListener('input', function(e) {
            // Permitir apenas números e ponto decimal
            let value = e.target.value;
            value = value.replace(/[^0-9.]/g, '');
            
            // Permitir apenas um ponto decimal
            const parts = value.split('.');
            if (parts.length > 2) {
                value = parts[0] + '.' + parts.slice(1).join('');
            }
            
            // Limitar casas decimais a 2
            if (parts[1] && parts[1].length > 2) {
                value = parts[0] + '.' + parts[1].substring(0, 2);
            }
            
            e.target.value = value;
        });
        
        // Permitir Enter para continuar
        customInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                processCustomValue();
            }
        });
    }
});

// Função para adicionar efeitos sonoros (opcional)
function playClickSound() {
    // Implementar som de clique se necessário
    // const audio = new Audio('assets/click.mp3');
    // audio.play().catch(() => {});
}

// Adicionar eventos de clique com som
document.addEventListener('click', function(e) {
    if (e.target.tagName === 'BUTTON') {
        playClickSound();
    }
});

// Função para vibração em dispositivos móveis
function vibrate() {
    if (navigator.vibrate) {
        navigator.vibrate(50);
    }
}

// Adicionar vibração aos botões importantes
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('btn-primary') || 
        e.target.classList.contains('btn-copy')) {
        vibrate();
    }
});

// Prevenção de zoom duplo toque em iOS
let lastTouchEnd = 0;
document.addEventListener('touchend', function(event) {
    const now = (new Date()).getTime();
    if (now - lastTouchEnd <= 300) {
        event.preventDefault();
    }
    lastTouchEnd = now;
}, false);

// Função para debug (remover em produção)
function debugInfo() {
    console.log('Progresso atual:', currentProgress);
    console.log('Valor temporário:', tempValue);
    console.log('Valor customizado:', customValue);
    console.log('Meta total:', META_TOTAL);
}

// Expor função de reset para console (para testes)
window.resetVaquinha = resetProgress;
window.debugVaquinha = debugInfo;

