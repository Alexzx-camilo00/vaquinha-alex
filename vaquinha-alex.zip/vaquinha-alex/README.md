# Site de Vaquinha do Alex

Site mobile-first moderno para arrecadação de fundos com sistema de doações via Pix.

## 🎯 Características

- **Design Mobile-First**: Otimizado para dispositivos móveis
- **Degradê Moderno**: Fundo com transição de preto para laranja escuro
- **Barra de Progresso**: Azul brilhante com atualização em tempo real
- **Sistema de Doações**: Valores pré-definidos e opção customizada
- **Chaves Pix Específicas**: Cada valor tem sua própria chave Pix
- **Funcionalidade de Cancelamento**: Botão "DESISTIR" que reverte o progresso
- **Transições Suaves**: Animações entre páginas
- **Persistência de Dados**: Progresso salvo no localStorage

## 📱 Fluxo de Navegação

### 1. Página Inicial
- Título: "Ajude o Alex a bater a meta!"
- Meta: R$400
- Barra de progresso mostrando valor atual
- Botão "AJUDAR"

### 2. Seleção de Valores
- Pergunta: "Quanto você gostaria de ajudar?"
- Botões: R$20, R$30, R$40, R$50, R$100, EU ESCOLHO

### 3. Páginas de Doação (R$20-R$100)
- Valor da doação escolhida
- Chave Pix específica para cada valor
- Botão "Copiar" para copiar a chave
- Botão "PRONTO" para confirmar doação
- Botão "DESISTIR" para cancelar

### 4. Página EU ESCOLHO
- Campo numérico para valor customizado
- Validação de entrada
- Botão "Continuar"

### 5. Doação Customizada
- Chave Pix genérica
- Mesma estrutura das doações pré-definidas

### 6. Agradecimento
- Mensagem: "Obrigado, você é especial"
- Botão para voltar ao início

## 🔧 Funcionalidades Técnicas

### Barra de Progresso
- Meta total: R$400
- Atualização dinâmica conforme doações
- Persistência no localStorage
- Animação suave de preenchimento

### Sistema de Cancelamento
- Botão "DESISTIR" em todas as páginas de doação
- Reverte o progresso para o estado anterior
- Limpa valores temporários
- Retorna à página inicial

### Cópia de Pix
- Seleção automática do texto
- Feedback visual (botão muda para "Copiado!")
- Suporte a diferentes navegadores
- Fallback para seleção manual

### Validação de Entrada
- Campo numérico aceita apenas números e ponto decimal
- Máximo 2 casas decimais
- Validação de valores maiores que zero
- Suporte a tecla Enter

## 🎨 Design

### Cores
- **Fundo**: Degradê linear de #000000 → #1a1a1a → #2d1810 → #8B4513
- **Barra de Progresso**: Degradê azul (#00BFFF → #1E90FF → #0080FF)
- **Botão Principal**: Degradê laranja (#FF8C00 → #FF7F00 → #FF6500)
- **Botões de Valor**: Degradê azul (#4A90E2 → #357ABD → #2E6DA4)
- **EU ESCOLHO**: Degradê roxo (#8A2BE2 → #7B68EE → #6A5ACD)
- **Copiar**: Degradê verde (#32CD32 → #228B22 → #006400)
- **Desistir**: Degradê cinza (#666 → #555 → #444)

### Tipografia
- Fonte: Arial, sans-serif
- Títulos: 2.5rem (mobile: 2rem)
- Perguntas: 1.8rem (mobile: 1.5rem)
- Botões: 1.3rem (mobile: 1.2rem)
- Sombras de texto para melhor legibilidade

### Layout
- Container máximo: 400px
- Padding: 20px (mobile: 15px)
- Botões com altura mínima de 18px de padding
- Grid 2x3 para botões de valores
- Espaçamento consistente entre elementos

## 📋 Chaves Pix

### Valores Pré-definidos
- **R$20**: Mensagem "Obrigado! Voce e demais!"
- **R$30**: Mensagem "Valeuuuuuuuuuuuuuui"
- **R$40**: Mensagem "Muito obrigado pelos 40!"
- **R$50**: Mensagem "ta podendo em! Obrigado!"
- **R$100**: Mensagem "Nuuuuuu, valeu de maissssss"

### Valor Customizado
- Chave genérica: "Cofrinho de Alexsandro Camilo De Souz"
- Aceita qualquer valor digitado pelo usuário

## 🚀 Como Usar

1. Abra o arquivo `index.html` em qualquer navegador
2. O site funciona offline (não requer servidor)
3. Todas as funcionalidades estão implementadas
4. O progresso é salvo automaticamente no navegador

## 📱 Recursos Mobile

- **Touch-friendly**: Botões grandes e fáceis de tocar
- **Swipe Support**: Gesto de deslizar para voltar
- **Vibração**: Feedback tátil em botões importantes
- **Prevenção de Zoom**: Evita zoom acidental em iOS
- **Responsivo**: Adapta-se a diferentes tamanhos de tela

## 🔧 Funções de Debug

Para desenvolvedores, as seguintes funções estão disponíveis no console:

```javascript
// Resetar progresso da vaquinha
resetVaquinha();

// Ver informações de debug
debugVaquinha();
```

## 📁 Estrutura de Arquivos

```
vaquinha-alex/
├── index.html          # Página principal (SPA)
├── css/
│   └── style.css       # Estilos CSS
├── js/
│   └── script.js       # Lógica JavaScript
├── README.md           # Esta documentação
└── PLANEJAMENTO.md     # Documentação de planejamento
```

## ✅ Funcionalidades Testadas

- ✅ Navegação entre todas as páginas
- ✅ Barra de progresso dinâmica
- ✅ Cópia de chaves Pix
- ✅ Sistema de cancelamento (DESISTIR)
- ✅ Validação de entrada customizada
- ✅ Persistência de dados
- ✅ Responsividade mobile
- ✅ Transições suaves
- ✅ Feedback visual
- ✅ Compatibilidade com navegadores

## 🎯 Meta da Vaquinha

**Objetivo**: R$400  
**Progresso**: Atualizado em tempo real  
**Beneficiário**: Alex (Alexsandro Camilo de Souza)

---

*Site desenvolvido com foco em usabilidade mobile e experiência do usuário otimizada para doações via Pix.*

